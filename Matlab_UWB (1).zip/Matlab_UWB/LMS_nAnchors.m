%Anchors
%distMed

function P = LMS_nAnchors(Anchors, distMed)

xAnchors = Anchors - Anchors(1,:).* ones(size(Anchors));
dAnchors = xAnchors(2:end, :);
dist1j = diag(dAnchors * dAnchors');
distMedQuad = distMed' .* distMed';
xdistMedQuad = distMedQuad(1) - distMedQuad;
difdistMedQuad = xdistMedQuad(2:end);
b = 1/2 * (difdistMedQuad + dist1j);
P = inv(dAnchors' * dAnchors) * dAnchors' * b + Anchors(1,:)' ;
%P = (inv(dAnchors' * dAnchors) * dAnchors' * b); 
end
