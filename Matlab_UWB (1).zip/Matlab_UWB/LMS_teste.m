chdir 'C:\Users\Usuario\Desktop\Matlab_UWB\medidas_080524'
load med02.txt
chdir 'C:\Users\Usuario\Desktop\Matlab_UWB'

dados = med01;

A1 = [2.058, 0.000, 0.000];
A2 = [0.000, 0.912, 0.001];
A3 = [2.058, 0.912, 0.002];
A4 = [0.000, 0.000, 0.003];


A = [A1; A2; A3; A4];

for ii = 1:size(dados, 1)

    distancias = dados(ii,1:2:7);
    desvios = dados(ii,2:2:8);

    %P(:,ii) = trilaterate3D(A1, A2, A3, A4, distancias);
    %nP0(ii,:) = P(:,ii)';
    %nP1(ii,:) = errodist(A, P(:,ii)', distancias);
    nP2(ii,:) = LMS_nAnchors(A, distancias);
    %nP3(ii,:) = errodist(A, nP2(ii,:), distancias);
    nP4(ii,:) = LMSP_nAnchors(A, distancias, desvios);

end


dist = dados(:,1:2:7);
desv = dados(:,2:2:8);

figure(1)
plot(dist(:,1))
hold
plot(dist(:,1)+desv(:,1),'k')
plot(dist(:,1)-desv(:,1),'k')

figure(2)
plot(dist(:,2))
hold
plot(dist(:,2)+desv(:,2),'k')
plot(dist(:,2)-desv(:,2),'k')
