
chdir 'C:\Users\Usuario\Desktop\Matlab_UWB\ENSAIO2_3004'
load T1_Clean.txt;
chdir 'C:\Users\Usuario\Desktop\Matlab_UWB'

A1 = [1, 1.02, 0.625];
A2 = [7.29, 2.67, 1.3];
A3 = [6.22, 7.5, 0.625];
A4 = [1, 7.5, 1.28];
A5 = [3.9, 0.51, 1.29];
A6 = [4.08, 9.07, 1.3];

A = [A1; A2; A3; A4; A5; A6];


for ii = 1:size(T1_Clean, 1)

    distancias = T1_Clean(ii,:);

    P(:,ii) = trilaterate3D(A1, A2, A3, A4, distancias);
    nP0(ii,:) = P(:,ii)';
    nP1(ii,:) = errodist(A, P(:,ii)', distancias);
    nP2(ii,:) = LMS_nAnchors(A, distancias);
    nP3(ii,:) = errodist(A, nP2(ii,:), distancias);

end

figure

plot3(nP0(:,1),nP0(:,2),nP0(:,3),'b.')
hold on
plot3(nP1(:,1),nP1(:,2),nP1(:,3),'r.')
plot3(nP2(:,1),nP2(:,2),nP2(:,3),'m.')
plot3(nP3(:,1),nP3(:,2),nP3(:,3),'k.')
