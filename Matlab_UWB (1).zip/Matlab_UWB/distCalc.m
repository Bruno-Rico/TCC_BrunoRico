function d = distCalc(T, A)
d = sqrt((T(1)-A(1,1))^2 + (T(2)-A(2))^2 + (T(3)-A(3))^2);