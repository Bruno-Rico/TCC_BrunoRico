 function [v, indices_Or] = encontrar_menores_quatro(vetor)
    % Ordena o vetor     
     [var, indices] = sort(vetor);
     v = var(1:4);
    indices_Or = indices(1:4);
 end