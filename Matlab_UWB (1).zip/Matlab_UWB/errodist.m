% mAnchors: Matriz com as posições de todas as âncoras;
% pEst: Posição estimada;
% distMed: Vetor com as distâncias medidas pelo UWB.
function  P = errodist(mAnchors, pEst, distMed)

pLoop = pEst'; 
for loop = 1 : 6

    % fe: Matriz função erro.
    for i = 1 : length(distMed)
        D(i) = distCalc(mAnchors(i,:), pLoop);
        fe(i,1) =  D(i) - distMed(i);
    end
    
    % J: Matriz Jacobiana.
    J = zeros(size(mAnchors));
    for i = 1 : size(mAnchors, 1)
        J(i,:) = (pLoop' - mAnchors(i,:))/D(i);
    end
    

    pLoop = pLoop - inv(J' * J) * J' * fe;
    %Plog(:,loop) = pLoop; 
end

P = pLoop; 

end
