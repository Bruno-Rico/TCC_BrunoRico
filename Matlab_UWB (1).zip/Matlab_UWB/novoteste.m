%% cenário
figure
%subplot(1,2,1);
s = 0.1;
D = [0,0,0,0];
v = [0,0,0,0];
P1 = [0, 1, 1];
P2 = [0, 5, 2];
P3 = [2, 5, 1.3];
P4 = [2, 2.5, 2];
P5 = [3, 3, 3];
P6 = [3, 1, 1];
P7 = [5, 5, 2.5];

Pa = [P1; P2; P3; P4; P5; P6; P7];

% Posição das ancora 1
%xx = s*[0 0 1 1 0] + P1(1); 
%yy = s*[0 1 1 0 0] + P1(2);
%subplot(1,2,1);
%plot(xx,yy,'r', 'LineWidth',2)
%hold on
%text(P1(1), P1(2)-2*s, 'Anchor 1')

% Posição das ancora 2
%xx = s*[0 0 1 1 0] + P2(1); 
%yy = s*[0 1 1 0 0] + P2(2);
%subplot(1,2,1);
%plot(xx,yy,'r', 'LineWidth',2)
%hold on
%text(P2(1), P2(2)-2*s, 'Anchor 2')

% Posição das ancora 3
%xx = s*[0 0 1 1 0] + P3(1); 
%yy = s*[0 1 1 0 0] + P3(2);
%subplot(1,2,1);
%plot(xx,yy,'r', 'LineWidth',2)
%hold on
%text(P3(1), P3(2)-2*s, 'Anchor 3')

% Posição das ancora 4
%xx = s*[0 0 1 1 0] + P4(1); 
%yy = s*[0 1 1 0 0] + P4(2);
%subplot(1,2,1);
%plot(xx,yy,'r', 'LineWidth',2)
%hold on
%text(P4(1), P4(2)-2*s, 'Anchor 4')

t = linspace(0, 100, 250);
w = 0.1;
y = 4*sin(2*w*t)
x = 4*sin(w*t)
z = 1;
%plot(x,y)
%axis equal
%axis([-5 5 -5 5])
%grid on
%hold on

for nn = 1:250

    subplot(1,2,1);
    plot(x,y)
    %axis equal
    axis([-5 5 -5 5])
    grid on
    hold on
   
  d1(nn) = sqrt((P1(1)-x(nn))^2 + (P1(2)-y(nn))^2 + ((P1(3)-z)^2));
  d2(nn) = sqrt((P2(1)-x(nn))^2 + (P2(2)-y(nn))^2 + ((P2(3)-z)^2));
  d3(nn) = sqrt((P3(1)-x(nn))^2 + (P3(2)-y(nn))^2 + ((P3(3)-z)^2));
  d4(nn) = sqrt((P4(1)-x(nn))^2 + (P4(2)-y(nn))^2 + ((P4(3)-z)^2));

   %d1(nn) = d1(nn) + (rand-0.5)*0.1;
   %d2(nn) = d2(nn) + (rand-0.5)*0.1;
   %d3(nn) = d3(nn) + (rand-0.5)*0.1;
   %d4(nn) = d4(nn) + (rand-0.5)*0.1;
   
    viscircles([x(nn) y(nn)], 0.1, 'Color', 'm', 'LineWidth',2)
    refreshdata
    drawnow

    
    %axis equal
    D(1) = d1(nn);
    D(2) = d2(nn);
    D(3) = d3(nn);
    D(4) = d4(nn);
    % P = trilaterate3D(P1, P2, P3, P4, D);
    P = trilaterate3D(Pa(1,:), Pa(2,:), Pa(3,:), Pa(4,:), D);

      D(1)= sqrt((P1(1)-P(1))^2 + (P1(2)-P(2))^2 + ((P1(3)-P(3))^2));
      D(2)= sqrt((P2(1)-P(1))^2 + (P2(2)-P(2))^2 + ((P2(3)-P(3))^2));
      D(3)= sqrt((P3(1)-P(1))^2 + (P3(2)-P(2))^2 + ((P3(3)-P(3))^2));
      D(4)= sqrt((P4(1)-P(1))^2 + (P4(2)-P(2))^2 + ((P4(3)-P(3))^2)); 
      D(5)= sqrt((P5(1)-P(1))^2 + (P5(2)-P(2))^2 + ((P5(3)-P(3))^2)); 
      D(6)= sqrt((P6(1)-P(1))^2 + (P6(2)-P(2))^2 + ((P6(3)-P(3))^2)); 
      D(7)= sqrt((P7(1)-P(1))^2 + (P7(2)-P(2))^2 + ((P7(3)-P(3))^2)); 
      [v, ind] = encontrar_menores_quatro(D);
      disp(ind); 
      subplot(1,2,2); 
      plot(x,y)
      axis([-5 5 -5 5])
      grid on
      hold on
      P = trilaterate3D(Pa(ind(1),:), Pa(ind(2),:), Pa(ind(3),:), Pa(ind(4),:), v);
      viscircles([P(1), P(2)], 0.1, 'Color', 'm', 'LineWidth',2);
      refreshdata
      drawnow

      
end

 function P = trilaterate3D(P1, P2, P3, P4, distances)
    % Matriz A com base nos vetores direcionais
    A = 2 * [(P2 - P1); (P3 - P1); (P4 - P1)];

    % Vetor b com base nas equações das esferas
    b = [norm(P2 - P1)^2 - distances(2)^2 + distances(1)^2;
         norm(P3 - P1)^2 - distances(3)^2 + distances(1)^2;
         norm(P4 - P1)^2 - distances(4)^2 + distances(1)^2];

    % Solução do sistema linear para encontrar as coordenadas x, y, z de P
    P = A \ b;  
    P(1) = P(1) + P1(1);
    P(2) = P(2) + P1(2);
    P(3) = P(3) + P1(3);
 end

 function [v, indices_Or] = encontrar_menores_quatro(vetor)
    % Ordena o vetor     
     [v, indices] = sort(vetor);
    indices_Or = indices(1:4);
 end

 