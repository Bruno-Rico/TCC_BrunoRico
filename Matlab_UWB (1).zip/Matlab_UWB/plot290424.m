
%% 
chdir 'C:\Users\Usuario\Desktop\Matlab_UWB\aqs_290424';
load 360_T1mod.txt
load 360_T2mod.txt

chdir 'C:\Users\Usuario\Desktop\Matlab_UWB';

dados1 = X360_T1mod;
dados2 = X360_T2mod;

a11 = [1, 1];
a22 = [0.78, 7.44 ];
a33 = [6.92, 0.77];

A1 = [1, 1.02, 0.625];
A2 = [7.29, 2.67, 1.3];
A3 = [6.22, 7.5, 0.625];
A4 = [1, 7.5, 1.28];
A5 = [3.9, 0.51, 1.29];
A6 = [4.08, 9.07, 1.3];

A = [A1; A2; A3; A4; A5; A6];

%A3 = [2.14 6.60 1.28];
%A4 = [8.75 1.51 1.28];

line([3.02 4.53], [7.43 7.43])
hold on
line([4.53 4.53], [7.43 5.61])
hold on
line([4.53 6.04], [5.61 5.61])
hold on
line([6.04 6.04], [5.61 3.79])
hold on
line([6.04 4.53], [3.79 3.79])
hold on
line([4.53 4.53], [3.79 1.97])
hold on
line([4.53 3.02], [1.97 1.97])
hold on
line([3.02 3.02], [1.97 3.79])
hold on
line([3.02 1.51], [3.79 3.79])
hold on
line([1.51 1.51], [3.79 5.61])
hold on
line([1.51 3.02], [5.61 5.61])
hold on
line([3.02 3.02], [5.61 7.43])
hold on

% 
% for ii = 1:size( T1_Clean,1)
%    P1(ii,:) = trilaterate3D(A1, A2, A3, A4, T1_Clean(ii,:));
% 
% 
%     Dis(1)= sqrt((A1(1)-P1(ii, 1))^2 + (A1(2)-P1(ii, 2))^2 + ((A1(3)-P1(ii, 3))^2));
%     Dis(2)= sqrt((A2(1)-P1(ii, 1))^2 + (A2(2)-P1(ii, 2))^2 + ((A2(3)-P1(ii, 3))^2));
%     Dis(3)= sqrt((A3(1)-P1(ii, 1))^2 + (A3(2)-P1(ii, 2))^2 + ((A3(3)-P1(ii, 3))^2));
%     Dis(4)= sqrt((A4(1)-P1(ii, 1))^2 + (A4(2)-P1(ii, 2))^2 + ((A4(3)-P1(ii, 3))^2)); 
%     Dis(5)= sqrt((A5(1)-P1(ii, 1))^2 + (A5(2)-P1(ii, 2))^2 + ((A5(3)-P1(ii, 3))^2)); 
%     Dis(6)= sqrt((A6(1)-P1(ii, 1))^2 + (A6(2)-P1(ii, 2))^2 + ((A6(3)-P1(ii, 3))^2)); 
%     [v, ind] = encontrar_menores_quatro(Dis);
%     P_test(ii,:) = trilaterate3D( A(ind(1),:), A(ind(2),:), A(ind(3),:), A(ind(4),:), v);  
% end
% 
% 
% 
% plot3(P_test(:,1), P_test(:,2),P_test(:,3), 'r.')
% grid on
% axis equal
% xlabel('Posição X (m)')
% ylabel('Posição Y (m)')
% 
% hold on;
% 
% for ii = 1:size( T1_Interference,1)
%    P2(ii,:) = trilaterate3D(A1, A2, A3, A4, T1_Interference(ii,:));
% 
% 
%     Dis(1)= sqrt((A1(1)-P2(ii, 1))^2 + (A1(2)-P2(ii, 2))^2 + ((A1(3)-P2(ii, 3))^2));
%     Dis(2)= sqrt((A2(1)-P2(ii, 1))^2 + (A2(2)-P2(ii, 2))^2 + ((A2(3)-P2(ii, 3))^2));
%     Dis(3)= sqrt((A3(1)-P2(ii, 1))^2 + (A3(2)-P2(ii, 2))^2 + ((A3(3)-P2(ii, 3))^2));
%     Dis(4)= sqrt((A4(1)-P2(ii, 1))^2 + (A4(2)-P2(ii, 2))^2 + ((A4(3)-P2(ii, 3))^2)); 
%     Dis(5)= sqrt((A5(1)-P2(ii, 1))^2 + (A5(2)-P2(ii, 2))^2 + ((A5(3)-P2(ii, 3))^2)); 
%     Dis(6)= sqrt((A6(1)-P2(ii, 1))^2 + (A6(2)-P2(ii, 2))^2 + ((A6(3)-P2(ii, 3))^2)); 
%     [v, ind] = encontrar_menores_quatro(Dis);
%     P_test2(ii,:) = trilaterate3D( A(ind(1),:), A(ind(2),:), A(ind(3),:), A(ind(4),:), v);  
% end
% 
% 
% 
% plot3(P_test2(:,1), P_test2(:,2),P_test2(:,3), 'b.')
% grid on
% axis equal
% xlabel('Posição X (m)')
% ylabel('Posição Y (m)')
% 
% hold on;

% for ii = 1:size(volta1,1)
%  P1(ii,:) = trilaterate3D(A1, A2, A3, A4, volta1(ii,:));
% end
% 
% plot3(P1(:,1), P1(:,2),P1(:,3), 'r.')
% 
% 
% hold on;

% for ii = 1:size(voltas345,1)
%   P5(ii,:) = trilaterate(a11, a22, a33,voltas345(ii,:));
% end
% 
% plot(P5(:,1), P5(:,2), 'b.');
% 
% 
% hold on;
