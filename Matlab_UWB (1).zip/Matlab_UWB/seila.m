

% teste trilaterate 3D

% parametros de teste -> P1 = (0, 0, 1), P2 = (0, 5, 2), P3 = (2, 5, 1.3), P4
% = (2, 2.5, 2). Resultado esperado -> P = (3, 3, 2), logo D1 = 2.828, D2 =
% 3.741, D3 = 0.583, D4 = 1.118;

P1 = [0, 1, 1];
P2 = [0, 5, 2];
P3 = [2, 5, 1.3];
P4 = [2, 2.5, 2];

D = [3.742, 3.605, 2.343, 1.118];


A = trilaterate3D(P1, P2, P3, P4, D);

fprintf('X: %.2f, Y: %.2f, Z: %.2f\n', A(1), A(2), A(3));

 