
chdir 'C:\Users\Usuario\Desktop\Matlab_UWB\ENSAIO2_3004'
load T1_Clean.txt;
chdir 'C:\Users\Usuario\Desktop\Matlab_UWB'

A1 = [7, 1, 0.035];
A2 = [4, 0.63, 1.275];
A3 = [0.51, 5.98, 1.265];
A4 = [7.17, 8.865, 1.3];
A5 = [1, 1, 0.635];
A6 = [2.01, 8, 1.295];
A7 = [0.175, 4, 0.035];
A8 = [7.265, 4.86, 2.82];
A9 = [4.39, 8.46, 0.635];

sa1 = 8;
sa2 = 9;
sa3 = 4;
sa4 = 1;
sa5 = 2;
sa6 = 7;
sa7 = 5;
sa8 = 3;



A = [A1; A2; A3; A4; A5; A6; A7; A8; A9];
A_2 = [A(sa1,:); A(sa2,:); A(sa3,:); A(sa4,:); A(sa5,:);A(sa6,:); A(sa7,:);A(sa8,:)];




for ii = 1:size(X9_ancoras, 1)

    teste2(ii,1) = X9_ancoras(ii,sa1);
    teste2(ii,2) = X9_ancoras(ii,sa2);
    teste2(ii,3) = X9_ancoras(ii,sa3);
    teste2(ii,4) = X9_ancoras(ii,sa4);
    teste2(ii,5) = X9_ancoras(ii,sa5);
    teste2(ii,6) = X9_ancoras(ii,sa6);
    teste2(ii,7) = X9_ancoras(ii,sa7);
    teste2(ii,8) = X9_ancoras(ii,sa8);


end




for ii = 1:size(X9_ancoras, 1)

    distancias = X9_ancoras(ii,:);
    dist_in(ii,1) = X9_ancoras(ii,sa1);
    dist_in(ii,2) = X9_ancoras(ii,sa2);
    dist_in(ii,3) = X9_ancoras(ii,sa3);
    dist_in(ii,4) = X9_ancoras(ii,sa4);

    P(:,ii) = trilaterate3D(A8, A9, A4, A1, dist_in);
    nP0(ii,:) = P(:,ii)';
    nP1(ii,:) = errodist(A, P(:,ii)', distancias);
    nP2(ii,:) = LMS_nAnchors(A, distancias);
    nP3(ii,:) = errodist(A, nP2(ii,:), distancias);

end

figure

plot3(nP0(:,1),nP0(:,2),nP0(:,3),'b.')
hold on
plot3(nP1(:,1),nP1(:,2),nP1(:,3),'r.')
plot3(nP2(:,1),nP2(:,2),nP2(:,3),'m.')
plot3(nP3(:,1),nP3(:,2),nP3(:,3),'k.')

% 
% for ii = 1:size( X9_ancoras,1)
%    P1(ii,:) = trilaterate3D(A1, A2, A3, A4, X9_ancoras(ii,1:4));
% 
% 
%     Dis(1)= sqrt((A1(1)-P1(ii, 1))^2 + (A1(2)-P1(ii, 2))^2 + ((A1(3)-P1(ii, 3))^2));
%     Dis(2)= sqrt((A2(1)-P1(ii, 1))^2 + (A2(2)-P1(ii, 2))^2 + ((A2(3)-P1(ii, 3))^2));
%     Dis(3)= sqrt((A3(1)-P1(ii, 1))^2 + (A3(2)-P1(ii, 2))^2 + ((A3(3)-P1(ii, 3))^2));
%     Dis(4)= sqrt((A4(1)-P1(ii, 1))^2 + (A4(2)-P1(ii, 2))^2 + ((A4(3)-P1(ii, 3))^2)); 
%     Dis(5)= sqrt((A5(1)-P1(ii, 1))^2 + (A5(2)-P1(ii, 2))^2 + ((A5(3)-P1(ii, 3))^2)); 
%     Dis(6)= sqrt((A6(1)-P1(ii, 1))^2 + (A6(2)-P1(ii, 2))^2 + ((A6(3)-P1(ii, 3))^2));
%     Dis(7)= sqrt((A7(1)-P1(ii, 1))^2 + (A7(2)-P1(ii, 2))^2 + ((A7(3)-P1(ii, 3))^2)); 
%     Dis(8)= sqrt((A8(1)-P1(ii, 1))^2 + (A8(2)-P1(ii, 2))^2 + ((A8(3)-P1(ii, 3))^2)); 
%     Dis(9)= sqrt((A9(1)-P1(ii, 1))^2 + (A9(2)-P1(ii, 2))^2 + ((A9(3)-P1(ii, 3))^2)); 
%     [v, ind] = encontrar_menores_quatro(Dis);
%     P_test(ii,:) = trilaterate3D( A(ind(1),:), A(ind(2),:), A(ind(3),:), A(ind(4),:), v);  
% end
% 
% plot3(P_test(:,1), P_test(:,2),P_test(:,3), 'r.')
% grid on
% axis equal
% xlabel('Posição X (m)')
% ylabel('Posição Y (m)')



