function P = trilaterate(Q1, Q2, Q3, distances)
    ex = (Q2 - Q1) / norm(Q2 - Q1);
    i = dot(ex, Q3 - Q1);
    a = Q3 - Q1 - i * ex;
    ey = a / norm(a);
   
    
    d = norm(Q2 - Q1);
    j = dot(ey, Q3 - Q1);
    
    x = (distances(1)^2 - distances(2)^2 + d^2) / (2 * d);
    y = (distances(1)^2 - distances(3)^2 + i^2 + j^2) / (2 * j) - (i / j) * x;
    
    P = Q1 + x * ex + y * ey;
end