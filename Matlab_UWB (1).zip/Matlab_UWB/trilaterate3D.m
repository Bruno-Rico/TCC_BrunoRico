 function P = trilaterate3D(P1, P2, P3, P4, distances)
    % Matriz A com base nos vetores direcionais
    A = 2 * [(P2 - P1); (P3 - P1); (P4 - P1)];

    % Vetor b com base nas equações das esferas
    b = [norm(P2 - P1)^2 - distances(2)^2 + distances(1)^2;
         norm(P3 - P1)^2 - distances(3)^2 + distances(1)^2;
         norm(P4 - P1)^2 - distances(4)^2 + distances(1)^2];

    % Solução do sistema linear para encontrar as coordenadas x, y, z de P
    P = A \ b;  
    P(1) = P(1) + P1(1);
    P(2) = P(2) + P1(2);
    P(3) = P(3) + P1(3);
    
    % if ( P(3) < 0 )
    %     P(3) = P(3) * -1;
    % end
    % O resultado P já é a localização absoluta em relação ao ponto [0,0,0]
    % Não é necessário adicionar P1
end