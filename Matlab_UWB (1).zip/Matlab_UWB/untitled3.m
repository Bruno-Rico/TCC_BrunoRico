%% 
Anchor1 = [6.92 0.77];
Anchor2 = [0.78 7.44];
Anchor3 = [1.0  1.0];

line([3.02 4.53], [7.43 7.43])
hold on
line([4.53 4.53], [7.43 5.61])
hold on
line([4.53 6.04], [5.61 5.61])
hold on
line([6.04 6.04], [5.61 3.79])
hold on
line([6.04 4.53], [3.79 3.79])
hold on
line([4.53 4.53], [3.79 1.97])
hold on
line([4.53 3.02], [1.97 1.97])
hold on
line([3.02 3.02], [1.97 3.79])
hold on
line([3.02 1.51], [3.79 3.79])
hold on
line([1.51 1.51], [3.79 5.61])
hold on
line([1.51 3.02], [5.61 5.61])
hold on
line([3.02 3.02], [5.61 7.43])
hold on

for ii = 1:size(volta1,1)
    P1(ii,:) = trilaterate(Anchor1, Anchor2, Anchor3, volta1(ii,:));
end

plot3(P1(:,1), P1(:,2), ones(size(P1)), 'r.')
grid on
axis equal
xlabel('Posição X (m)')
ylabel('Posição Y (m)')

hold on;

for ii = 1:size(volta2,1)
    P2(ii,:) = trilaterate(Anchor1, Anchor2, Anchor3, volta2(ii,:));
end

plot3(P2(:,1), P2(:,2), ones(size(P2)), 'b.')


hold on;

for ii = 1:size(voltas345,1)
    P3(ii,:) = trilaterate(Anchor1, Anchor2, Anchor3, voltas345(ii,:));
end

plot3(P3(:,1), P3(:,2),ones(size(P3)), 'm.')