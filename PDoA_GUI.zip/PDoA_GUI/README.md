# PDoA GUI QT Windows application 
Compiled on QT 5.15.1 with MinGW 7.3.0 32-bit toolchain. 


signed
16/03/2021
