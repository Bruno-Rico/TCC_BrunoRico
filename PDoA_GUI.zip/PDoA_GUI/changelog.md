Release 1.0 (15 Mar 2021)
Initial release
Known issues:
1) Use IMU tickbox and changing the ranging rate sometimes doesn�t work. Unjoining the Tag and joining it back helps.
1) MiniMap doesn�t show the boundaries correctly
2) Not every picture format can be loaded as a floorplan (png usually work, jpg don�t)
