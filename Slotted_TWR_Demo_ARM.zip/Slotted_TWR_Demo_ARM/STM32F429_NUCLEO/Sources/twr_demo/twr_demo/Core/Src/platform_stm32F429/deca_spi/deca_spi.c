/**
 * @file      deca_spi.c
 *
 * @brief     SPI functions to interface to DW3000 chip's from STM32.
 *
 *            Pure "HAL" SPI Driver implementation is very slow.
 *
 *            We use the combination of HAL and LL drivers:
 *            CubeMX HAL is used to initialise SPI & DMA (see main.c).
 *            And the LL is used thereafter in the operation.
 *
 *              The ideal SPI time to read 5 bytes is ~1.2us on 36MHz.
 *            With LL driver it takes 4.2us for the reading of SYS_STATUS over DMA
 *            The constant overhead for all DMA transactions is ~3us.
 *            ~1.6us after selecting of SPI_CS, and then 1.4us to de-assert of the SPI_CS.
 *
 *            12KB accumulator of the DW3000:
 *            DMA: ~2.7ms : effectively equivalent to 36MHz SPI clock
 *            non-DMA: ~7ms : effectively equivalent to 14MHz SPI clock
 *
 *
 * @author    Decawave
 *
 * @attention Copyright 2017-2019 (c) Decawave Ltd, Dublin, Ireland.
 *            All rights reserved.
 *
 */

#include "port.h"
#include "assert.h"

//-----------------------------------------------------------------------------
// This buffer is used for reading/writing of short transactions
#if defined(DMA_SPI)
#define SPI_BUFFLEN        (16)
static  uint8_t spi_TmpBuffer[SPI_BUFFLEN];
#endif

extern SPI_HandleTypeDef hspi1;



//-----------------------------------------------------------------------------
#include "stm32f4xx_ll_dma.h"
#include "stm32f4xx_ll_spi.h"
#include "stm32f4xx_hal.h"

static
spi_handle_t spi_handler
=
{//SPI1 clocked from 72MHz
    .phspi          = &hspi1,
    .prescaler_slow = SPI_BAUDRATEPRESCALER_16,  // 4.5 MHz
    .prescaler_fast = SPI_BAUDRATEPRESCALER_2,   // 36 MHz
    .dmaRx          = DMA2,
    .streamRx       = LL_DMA_STREAM_2,
    .channelRx      = LL_DMA_CHANNEL_3,
    .dmaTx          = DMA2,
    .streamTx       = LL_DMA_STREAM_3,
    .channelTx      = LL_DMA_CHANNEL_3,
    .csPin          = DW_CS_Pin,
    .csPort         = DW_CS_GPIO_Port,
    .Lock           = HAL_UNLOCKED,
    .TxRxComplete     = 0,
#if defined(DMA_SPI)
    .pBuf           = spi_TmpBuffer,
#else
    .pBuf             = NULL
#endif
};

//------------------------------------------------------------------------------
// DW chip description
const dw_t dw_chip
=
{
    .irqPin        = DW_IRQ_Pin,
    .irqPort       = DW_IRQ_GPIO_Port,
    .irqN          = EXTI15_10_IRQn,
    .rstPin        = DW_RST_Pin,
    .rstPort       = DW_RST_GPIO_Port,
    .wakeUpPin     = DW_WUP_Pin,
    .wakeUpPort    = DW_WUP_GPIO_Port,
    .rstIrqN       = EXTI15_10_IRQn,
    .pSpi          = &spi_handler
};

const dw_t *pDwChip = &dw_chip;

//-----------------------------------------------------------------------------

/* @fn  set_dw_spi_slow_rate
 * @brief sets slow SPI clock speed for the DW chip
 *        left for compatibility.
 * */
void set_dw_spi_slow_rate(void)
{
    spi_handle_t *p = pDwChip->pSpi;
    p->phspi->Init.BaudRatePrescaler = p->prescaler_slow;
    __DSB();
    HAL_SPI_Init(p->phspi);
}

/* @fn      set_dw_spi_fast_rate
 * @brief   sets High SPI clock speed for the DW chip
 * */
void set_dw_spi_fast_rate(void)
{
    spi_handle_t *p = pDwChip->pSpi;
    p->phspi->Init.BaudRatePrescaler = p->prescaler_fast;
    __DSB();
    HAL_SPI_Init(p->phspi);
}


/****************************************************************************//**
 *
 *                              DWxxx SPI section
 *
 *******************************************************************************/
#if !defined(DMA_SPI)
/*!
 * @fn  openspi()
 * @brief
 * Low level abstract function to open and initialise access to the SPI device.
 * returns 0 for success, or -1 for error
 */
int openspi(/*SPI_TypeDef* SPIx*/)
{
    return 0;
}


/*!
 * @fn  closespi()
 * @brief
 * Low level abstract function to close the the SPI device.
 * returns 0 for success, or -1 for error
 */
int closespi(void)
{
    return 0;
}


/*!
 * @fn  writetospi()
 * @brief
 * Low level abstract function to write to the SPI
 * Takes two separate byte buffers for write header and write data
 * returns 0 for success, or -1 for error
 */
int writetospi(uint16_t          headerLength,
               const    uint8_t *headerBuffer,
               uint16_t          bodyLength,
               const    uint8_t *bodyBuffer)
{
    spi_handle_t *p = pDwChip->pSpi;
    /* Blocking: Check whether the previous transfer has been finished */
    while(p->Lock == HAL_LOCKED);
    __HAL_LOCK(p);                    //"return HAL_BUSY;" if locked

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET); /**< Put chip select line low */

    HAL_SPI_Transmit(p->phspi, (uint8_t *)&headerBuffer[0], headerLength, 10);    /* Send header in polling mode */
    HAL_SPI_Transmit(p->phspi, (uint8_t *)&bodyBuffer[0], bodyLength, 10);        /* Send data in polling mode */

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET); /**< Put chip select line high */

    __HAL_UNLOCK(p);
    return 0;
}

/**---------------------------------------
 * Function: writetospiwithcrc()
 *
 * Low level abstract function to write to the SPI when SPI CRC mode is used
 * Takes two separate byte buffers for write header and write data, and a CRC8 byte which is written last
 * returns 0 for success, or -1 for error
 */
int writetospiwithcrc(
                uint16_t      headerLength,
                const uint8_t *headerBuffer,
                uint16_t      bodyLength,
                const uint8_t *bodyBuffer,
                uint8_t       crc8)
{
    spi_handle_t *p = pDwChip->pSpi;
    /* Blocking: Check whether the previous transfer has been finished */
    while(p->Lock == HAL_LOCKED);
    __HAL_LOCK(p);    //"return HAL_BUSY;" if locked

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET); /**< Put chip select line low */

    HAL_SPI_Transmit(p->phspi, (uint8_t *)&headerBuffer[0], headerLength, 10);    /* Send header in polling mode */
    HAL_SPI_Transmit(p->phspi, (uint8_t *)&bodyBuffer[0], bodyLength, 10);        /* Send data in polling mode */
    HAL_SPI_Transmit(p->phspi, (uint8_t *)&crc8, 1, 10);                          /* Send data in polling mode */

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET); /**< Put chip select line high */

    __HAL_UNLOCK(p);
    return 0;
} // end writetospiwithcrc()


/**---------------------------------------
 * Function: readfromspi()
 *
 * Low level abstract function to read from the SPI
 * Takes two separate byte buffers for write header and read data
 * returns the offset into read buffer where first byte of read data may be found,
 * or returns -1 if there was an error
 */
int readfromspi(uint16_t          headerLength,
                /*const*/ uint8_t     *headerBuffer,
                uint16_t          readlength,
                uint8_t         *readBuffer)
{
    spi_handle_t *p = pDwChip->pSpi;
    /* Blocking: Check whether the previous transfer has been finished */
    while(p->Lock == HAL_LOCKED);
    __HAL_LOCK(p);    //"return HAL_BUSY;" if locked

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET); /**< Put chip select line low */

    /* Send header */
    for(int i=0; i<headerLength; i++)
    {
        HAL_SPI_Transmit(p->phspi, (uint8_t*)&headerBuffer[i], 1, HAL_MAX_DELAY); //No timeout
    }

    /* for the data buffer use LL functions directly as the HAL SPI read function
     * has issue reading single bytes */
    while(readlength-- > 0)
    {
        /* Wait until TXE flag is set to send data */
        while(__HAL_SPI_GET_FLAG(p->phspi, SPI_FLAG_TXE) == RESET)
        {
        }

        p->phspi->Instance->DR = 0; /* set the output to 0 (MOSI), this is necessary to keep MOSI line low.
                                                  e.g. when waking up DW3000 from DEEPSLEEP via dwt_spicswakeup() function.
                                                */

        /* Wait until RXNE flag is set to read data */
        while(__HAL_SPI_GET_FLAG(p->phspi, SPI_FLAG_RXNE) == RESET)
        {
        }

        (*readBuffer++) = p->phspi->Instance->DR;  //copy data read form (MISO)
    }

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET); /**< Put chip select line high */

    /* Process Unlocked */
    __HAL_UNLOCK(p);

    return 0;
} // end readfromspi()


#else

/*
 * @brief
 *
 * */
__STATIC_INLINE
void open_spi(spi_handle_t * p)
{
    /* Disable DMA channels by default */
    LL_DMA_DisableStream(p->dmaRx, p->streamRx);
    LL_DMA_DisableStream(p->dmaTx, p->streamTx);

    LL_SPI_Enable(p->phspi->Instance);

    LL_DMA_SetChannelSelection(p->dmaRx, p->streamRx, p->channelRx);
    LL_DMA_SetChannelSelection(p->dmaTx, p->streamTx, p->channelTx);

    /* Clearing all pending complete DMA flags if any */
    LL_DMA_ClearFlag_TC2(DMA2);
    LL_DMA_ClearFlag_TE2(DMA2);
    LL_DMA_ClearFlag_TC3(DMA2);
    LL_DMA_ClearFlag_TE3(DMA2);

    /* Enable DMA RX Buffer */
    LL_SPI_EnableDMAReq_RX(p->phspi->Instance);
    /* Enable DMA TX Buffer */
    LL_SPI_EnableDMAReq_TX(p->phspi->Instance);

    /* Enable DMA interrupts complete/error for Rx */
    LL_DMA_EnableIT_TC(p->dmaRx, p->streamRx);
    LL_DMA_EnableIT_TE(p->dmaRx, p->streamRx);

    /* Disable DMA Tx interrupts complete/error for Tx */
    LL_DMA_DisableIT_TC(p->dmaTx, p->streamTx);
    LL_DMA_DisableIT_TE(p->dmaTx, p->streamTx);
}

/* @brief
 *
 */
__STATIC_INLINE
void close_spi(spi_handle_t* p)
{
    /* Enable DMA interrupts complete/error */
    LL_DMA_DisableIT_TC(p->dmaRx, p->streamRx);
    LL_DMA_DisableIT_TE(p->dmaRx, p->streamRx);
    LL_DMA_DisableIT_TC(p->dmaTx, p->streamTx);
    LL_DMA_DisableIT_TE(p->dmaTx, p->streamTx);

    LL_SPI_DisableDMAReq_TX(p->phspi->Instance);
    LL_SPI_DisableDMAReq_RX(p->phspi->Instance);
    LL_SPI_Disable(p->phspi->Instance);

    p->TxRxComplete = 0;
}

/**
  * @brief  This function starts SPI DMA TX&RX
  *         Only RX IRQ will be generated
  */
__STATIC_INLINE
void Activate_SPI_TXRX(spi_handle_t* p)
{
    /* Enable DMA Rx interrupts complete/error */
    LL_DMA_EnableIT_TC(p->dmaRx, p->streamRx);
    LL_DMA_EnableIT_TE(p->dmaRx, p->streamRx);

    /* Enable DMA Rx & Tx Channels : Start transactions */
    LL_DMA_EnableStream(p->dmaRx, p->streamRx);
    LL_DMA_EnableStream(p->dmaTx, p->streamTx);
}

/**
  * @brief This function configures the DMA Channels for SPI
  * @note  This function is used to :
  *        1. Configure the DMA Rx Channel
  *        2. Configure the DMA Tx Channel
  *
  *        DMA's clock and NVIC interrupts should be  pre-configured
  *        by the BSP package
  *
  * @retval  None
  */
__STATIC_INLINE
void Configure_DMA_TXRX(spi_handle_t  *p,
                        const uint8_t *txBuffer,
                              uint8_t *rxBuffer,
                             uint32_t len)
{
    uint32_t periph_addr = LL_SPI_DMA_GetRegAddr(p->phspi->Instance);

    /* (1) Configure the DMA RX */
    LL_DMA_ConfigTransfer(p->dmaRx, p->streamRx,
                        LL_DMA_DIRECTION_PERIPH_TO_MEMORY | LL_DMA_PRIORITY_HIGH | LL_DMA_MODE_NORMAL |
                        LL_DMA_PERIPH_NOINCREMENT | LL_DMA_MEMORY_INCREMENT |
                        LL_DMA_PDATAALIGN_BYTE | LL_DMA_MDATAALIGN_BYTE);

    LL_DMA_ConfigAddresses(p->dmaRx, p->streamRx, periph_addr, (uint32_t)rxBuffer,
                        LL_DMA_DIRECTION_PERIPH_TO_MEMORY);
    LL_DMA_SetDataLength(p->dmaRx, p->streamRx, len);

    /* (2) Configure the DMA TX */
    LL_DMA_ConfigTransfer(p->dmaTx, p->streamTx,
                        LL_DMA_DIRECTION_MEMORY_TO_PERIPH | LL_DMA_PRIORITY_HIGH | LL_DMA_MODE_NORMAL |
                        LL_DMA_PERIPH_NOINCREMENT | LL_DMA_MEMORY_INCREMENT |
                        LL_DMA_PDATAALIGN_BYTE | LL_DMA_MDATAALIGN_BYTE);

    LL_DMA_ConfigAddresses(p->dmaTx, p->streamTx, (uint32_t)txBuffer, periph_addr,
                        LL_DMA_DIRECTION_MEMORY_TO_PERIPH);
    LL_DMA_SetDataLength(p->dmaTx, p->streamTx, len);
}


//-----------------------------------------------------------------------------

/*
 * @brief
 *  Limitation:  the addresses of the headerBuffer[SPI_BUFFLEN] should be less
 *  than _estack i.e. RAM end.
 *  Otherwise address overflow error will occur.
 *
 *  The best results we can achieve: 36MHz:
 *  reading of 0x3000 accumulator would take 2.7ms
 *  reading of DevID (5bytes) 4.2us.
 *
 * Note this implementation should not be used for DWxxx dwt_spicswakeup() function.
 * the Tx Buffer is not zeroed, so it will be the garbage on the MOSI line.
 * TODO: remove dwt_spicswakeup() from the driver code
 *
 * */
__STATIC_INLINE
int readfromspi_uni(spi_handle_t    *p,
                    uint16_t        headerLength,
                    const uint8_t   *headerBuffer,
                    uint32_t        readlength,
                    uint8_t            *readBuffer)
{
    uint32_t tmpLen, n = 0;

    if( (p->phspi->Instance != SPI1) )
    {
        error_handler(1, _ERR_SPI_DMA);
    }

    while(p->Lock == HAL_LOCKED);
    __HAL_LOCK(p);    //"return HAL_BUSY;" if locked

    open_spi(p);

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET);

    tmpLen = MIN(readlength+headerLength, SPI_BUFFLEN);

    Configure_DMA_TXRX (p, headerBuffer, p->pBuf, tmpLen);

    p->TxRxComplete = 0;
    __DSB();
    __ISB();

    Activate_SPI_TXRX(p);

    while (p->TxRxComplete != 1);

    for(int i = 0; i < tmpLen-headerLength; i++)
    {
        readBuffer[n + i] = p->pBuf[headerLength + i];
    }

    readlength  -= (tmpLen-headerLength);
    n           += (tmpLen-headerLength);

    /* for longer than SPI_BUFFLEN-headerLength reads, read the rest in one-go */
    if(readlength >0)
    {
        Configure_DMA_TXRX (p, readBuffer, &readBuffer[n], readlength);
        p->TxRxComplete = 0;
        __DSB();
        __ISB();
        Activate_SPI_TXRX(p);
        while (p->TxRxComplete != 1);
    }


    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET);

    close_spi(p);

    __HAL_UNLOCK(p);

    return _NO_ERR;
}

/*
 * */
__STATIC_INLINE
int writetospi_uni( spi_handle_t    *p,
                    uint16_t        headerLength,
                    const uint8_t   *headerBuffer,
                    uint32_t        bodyLength,
                    const uint8_t   *bodyBuffer)
{
    uint8_t        tmp_buf[SPI_BUFFLEN];
    uint32_t     tmpLen, n = 0;

    assert_param(headerLength < SPI_BUFFLEN );

    if( (p->phspi->Instance != SPI1) )
    {
        error_handler(1, _ERR_SPI_DMA);
    }

    while(p->Lock == HAL_LOCKED);
    __HAL_LOCK(p);    //"return HAL_BUSY;" if locked

    open_spi(p);

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET);

    for(int i = 0; i < headerLength; i++)
    {
        p->pBuf[i] =  headerBuffer[i];
    }

    do {
        tmpLen = MIN(bodyLength + headerLength, SPI_BUFFLEN);

        Configure_DMA_TXRX ( p, p->pBuf, tmp_buf, tmpLen);

        for(int i = 0; i < tmpLen - headerLength; i++)
        {
            p->pBuf[headerLength + i] =  bodyBuffer[n + i];
        }

        p->TxRxComplete = 0;

        Activate_SPI_TXRX(p);

        while (p->TxRxComplete != 1);

        bodyLength -= (tmpLen-headerLength);
        n            += (tmpLen-headerLength);
        headerLength= 0;

    } while (bodyLength > 0);

    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET);

    close_spi(p);

    __HAL_UNLOCK(p);

    return _NO_ERR;
}


//-----------------------------------------------------------------------------

int readfromspi(uint16_t        headerLength,
                /*const*/ uint8_t   *headerBuffer,
                uint16_t        readLength,
                uint8_t         *readBuffer)
{
    return readfromspi_uni( &spi_handler,
                            headerLength, headerBuffer,
                            readLength, readBuffer);
}

int writetospi(uint16_t         headerLength,
               const uint8_t    *headerBuffer,
               uint16_t         bodyLength,
               const uint8_t    *bodyBuffer)
{
    return writetospi_uni(&spi_handler,
                          headerLength, headerBuffer,
                          bodyLength, bodyBuffer);
}

int writetospiwithcrc(uint16_t  headerLength,
               const uint8_t    *headerBuffer,
               uint16_t         bodyLength,
               const uint8_t    *bodyBuffer,
               uint8_t          crc8)
{
    assert(true);

    return _ERR;
}

//-----------------------------------------------------------------------------
// Callbacks for IRQ:
// To speedup the transfer only RX DMA will be used

/**
  * @brief  Function called from DMA2Stream2 IRQ Handler when Rx transfer is completed
  * @param
  * @retval None
  */
void DMA2S2_ReceiveComplete_cb(void)
{
    {//this is for Tx (Tx is always first. Yes, called during DMA_Rx IRQ)
        LL_DMA_ClearFlag_TC3(DMA2);
        LL_DMA_DisableIT_TC(DMA2, LL_DMA_STREAM_3);
    }

    {//this is for Rx
        LL_DMA_ClearFlag_TC2(DMA2);
        LL_DMA_DisableIT_TC(DMA2, LL_DMA_STREAM_2);

        /* signal that the DMA Rx transfer completed */
        spi_handler.TxRxComplete = 1;
    }
}

void SPI1_TransferError_Callback(void)
{
    LL_DMA_ClearFlag_TE3(DMA2);
    LL_DMA_DisableIT_TE(DMA2, LL_DMA_STREAM_3);

    LL_DMA_ClearFlag_TE2(DMA2);
      LL_DMA_DisableIT_TE(DMA2, LL_DMA_STREAM_2);

    spi_handler.TxRxComplete = 1;
    error_handler(1, _ERR_SPI_DMA);
}

#endif

/****************************************************************************//**
 *
 *                                 END OF SPI section
 *
 *******************************************************************************/
 
