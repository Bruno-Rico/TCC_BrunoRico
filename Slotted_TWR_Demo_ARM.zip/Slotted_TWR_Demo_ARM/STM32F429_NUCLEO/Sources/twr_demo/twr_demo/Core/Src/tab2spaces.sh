#!/bin/bash
# 1 tab to 4spaces
find . -iname "*.c" -exec sed -i "s#\t#    #g" '{}' \;
find . -iname "*.h" -exec sed -i "s#\t#    #g" '{}' \;
find . -iname "*.cpp" -exec sed -i "s#\t#    #g" '{}' \;
